<?php include('sda_tables_data.php');


?>
<!DOCTYPE html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!--Responsive Meta-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--Title-->
    <title>Express Movers | Home Page</title>
    <!--Bootstrap Css-->
    <link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css" rel="stylesheet">
    <!--Font-awesome-->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">

    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">

    <!--Fonts Form Google Web Fonts-->
    <link href='http://fonts.googleapis.com/css?family=Lato:400,300,400italic,700,900,700italic' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Roboto:500' rel='stylesheet' type='text/css'>
    <!--Responsive Mobile Menu-->
    <link rel="stylesheet" href="../css/slicknav.css" />
    <!--Revolation Slider-->
    <link href="../rs-plugin/css/settings.css" rel="stylesheet">
    <!--Carousel Slider-->
    <link href="../css/owl.carousel.css" rel="stylesheet">
    <!--Main Style Css-->
    <link href="./style.css" rel="stylesheet">
    <!--Responsive-->
    <link href="../css/responsive.css" rel="stylesheet">


    <!-- CSS Files -->
    <link href="../assets/css/personal.css?" rel="stylesheet" />


    <!-- Custom styles for this page FOR TABLES -->
    <link href="../assets/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

    <!-- JS~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->

    <!--  Plugin for Sweet Alert js-->
    <!-- <script src="../assets/js/plugins/sweetalert2.js"></script> -->
    <script src="../assets/sweetalert/sweetalert.min.js"></script>
    <script src="../assets/sweetalert/sweetalert.js"></script>
    <!--  Plugin for Sweet Alert css -->
    <link href="../assets/sweetalert/sweetalert.css" rel="stylesheet">



    <!-- Google and Micosoft ajax jQuery -->
    <script src="../assets/jquery_ajax/google.jquery.min.js"></script>
    <script src="../assets/jquery_ajax/microsoft.jquery-3.4.1.min.js"></script>
    <!-- for online -->
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script> -->


    <!--  Notifications Plugin    -->
    <script src="../assets/js/plugins/bootstrap-notify.js"></script>
    <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
    <!-- <script src="../assets/js/material-dashboard.js?v=2.1.2" type="text/javascript"></script> -->




</head>