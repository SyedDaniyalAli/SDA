<?php include('./includes_sda/header.php'); ?>

<body>

    <?php include('./includes_sda/navbar.php'); ?>

    <!--Start Slider Area -->
    <section class="about_page_barner_area">
        <div class="barner_content">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                        <div class="barner_text text-center">
                            <h2>About Us</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
    <!--End Slider Area-->
    <!--Start Promotions Area -->
    <section class="promotions_area section_padding">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-lg-10 col-md-offset-1 col-lg-offset-1">
                    <div class="page_title text-center">
                        <h2>Who we are</h2>
                        <p>We provide services ranging from packing and moving to storage and relocating anywhere within the UAE.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 col-lg-4 ">
                    <div class="single_promotions text-center">
                        <div class="s_promotion_icon">
                            <img src="img/track_icon.png" alt="">
                        </div>
                        <h2>we make it faster</h2>
                        <p>We also expanded the list of our happy respected customers who have done business with us since the start of our operations, or are still doing business.</p>
                    </div>
                </div>
                <div class="col-md-4 col-lg-4 ">
                    <div class="single_promotions text-center">
                        <div class="s_promotion_icon">
                            <img src="img/hand_icon.png" alt="">
                        </div>
                        <h2>save and secure move</h2>
                        <p>It is our sincerity and dignity that we assure you. Customer instructions, suggestions, comments, and enquiries are taken extremely seriously at FOX Movers. We assure you of our swift actions and response.</p>
                    </div>
                </div>
                <div class="col-md-4 col-lg-4 ">
                    <div class="single_promotions text-center">
                        <div class="s_promotion_icon">
                            <img src="img/alarm_clock_icon.png" alt="">
                        </div>
                        <h2>on time delevery</h2>
                        <p>Our staff members are highly experienced in their field and thoroughly understand the delicacy of sensitive products and how to take good care of each object while packaging, processing, loading , unloading and rearranging them.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Promotions Area-->
    <!--Our Great Team Area -->
    <section class="process_area section_padding section_gray">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-12">
                    <div class="page_title text-center">
                        <h2>Our Responsible Team</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3 col-lg-3 col-sm-6">
                    <div class="single_team">
                        <a href=""><img src="img/team_1.jpg" alt=""></a>
                        <div class="team_discription">
                            <h3>Sunny Mirza</h3>
                            <p>ceo/founder</p>
                        </div>
                    </div>
                </div>
                <!-- <div class="col-md-3 col-lg-3 col-sm-6">
                    <div class="single_team">
                        <a href=""><img src="img/team_2.jpg" alt=""></a>
                        <div class="team_discription">
                            <h3></h3>
                            <p>driver</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-sm-6">
                    <div class="single_team">
                        <a href=""><img src="img/team_3.jpg" alt=""></a>
                        <div class="team_discription">
                            <h3></h3>
                            <p>delevery boy</p>
                        </div>
                    </div>
                </div> -->
                <div class="col-md-3 col-lg-3 col-sm-6">
                    <div class="single_team">
                        <a href=""><img src="img/team_4.jpg" alt=""></a>
                        <div class="team_discription">
                            <h3>Mohsin Mughal</h3>
                            <p>manager</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Our Great Team Area-->
    <!--Start Work Area  -->
    <section class="work_area section_padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-12">
                    <div class="page_title">
                        <h2>why we are best form other</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 col-lg-4">
                    <div class="single_work">
                        <a href=""><img class="alignleft" src="img/24_7.png" alt=""></a>
                        <h4>24/4 Service</h4>
                        <p>We provide you the 24/7 support, we work for you not count it's day or night</p>
                    </div>
                    <div class="single_work">
                        <a href=""><img class="alignleft" src="img/track_two.png" alt=""></a>
                        <h4>over 750 vehicles</h4>
                        <p>We have too much vehicle to delivery your essential at any place anywhere in UAE</p>
                    </div>
                    <div class="single_work">
                        <a href=""><img class="alignleft" src="img/man_icon.png" alt=""></a>
                        <h4>security cleared drivers</h4>
                        <p>We check all our customers before send to you, all drivers are security cleared</p>
                    </div>
                </div>
                <div class="col-md-4 col-lg-4">
                    <div class="single_work">
                        <a href=""><img class="alignleft" src="img/map_maker.png" alt=""></a>
                        <h4>live tracking</h4>
                        <p>We give you the facility to track your parcel's location live in you phone</p>
                    </div>
                    <div class="single_work">
                        <a href=""><img class="alignleft" src="img/sms_mail.png" alt=""></a>
                        <h4>Acknowledgment alerts</h4>
                        <p>We acknowledge you about any process of your parcels on time</p>
                    </div>
                    <div class="single_work">
                        <a href=""><img class="alignleft" src="img/fire_clock.png" alt=""></a>
                        <h4>estamited delevery time</h4>
                        <p>As our system is very efficent, they are punctual to delivery before esimated time</p>
                    </div>
                </div>
                <div class="col-md-4 col-lg-4">
                    <div class="work_area_img">
                        <img src="img/work_man_two.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Work Area-->
    <!--Start Contact Now Area -->
    <section class="contact_now_area_about_page">
        <div class="contact_now_area_overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-lg-6 col-md-offset-6 col-lg-offset-6">
                    <div class="contact_now_text">
                        <div class="contact_now_display_table_cell">
                            <h3>Our commitment to quality and security means that we only trained staff for packing and removal services. </h3>
                            <a href="contact-us.php" class="contact_button">CONTACT NOW</a>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <!--End Contact Now Area-->

    <?php include('./includes_sda/footer.php'); ?>