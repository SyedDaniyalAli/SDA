<!--Start Mobile Menu Area-->
<div id="preloader">
    <i class="fa fa-spinner fa-pulse fa-3x fa-fw margin-bottom"></i>
</div>
<div class="mobile_menu_area">
    <nav>
        <ul id="mobile_menu">
            <li class="active"><a href="index.php">Home</a></li>
            <li><a href="about-us.php">About Us</a></li>
            <li><a href="service.php">Service</a></li>
            <li><a href="storage-location.php">Team</a></li>
            <li><a href="contact-us.php">Contact Us</a></li>
        </ul>
    </nav>
</div>
<!--End Mobile Menu Area-->

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<a href="https://api.whatsapp.com/send?phone=51955081075&text=Hola%21%20Quisiera%20m%C3%A1s%20informaci%C3%B3n%20sobre%20Varela%202." class="float" target="_blank">
<i class="fa fa-whatsapp my-float"></i>
</a>

<!--Start Header area  -->
<div class="header_area">
    <div class="header_top_area">
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-lg-4">
                    <div class="header_top_menu">
                        <ul>
                            <li><a href="#">About Us</a></li>
                            <li><a href="#">Service</a></li>
                            <li><a href="#">Contact Us</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-2 col-lg-2 col-md-offset-6 col-lg-offset-6">
                    <div class="header_social_bookmark">
                        <ul>
                            <li><a href="https://www.facebook.com/Foxmoversuaecom-105520454505937"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="https://twitter.com/Foxmovers2"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="https://www.instagram.com/foxmoveruae/"><i class="fa fa-instagram"></i></a></li>
                            <li><a href="https://www.youtube.com/channel/UCAyQoggh5zErNScx6u9bYFA"><i class="fab fa-youtube"></i></a></li>
                            <li><a href="mailto:foxmovers137@gmail.com"><i class="fas fa-envelope"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="header_bottom_area">
        <div class="container">
            <div class="row">
                <div class="col-md-2 col-lg-2">
                    <div class="logo">
                        <a href="index.php"><img src="img/logo.png" alt="Fox Movers logo" style="height: 150px">
                        </a>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3">
                    <div class="email_us s_header">
                        <div><i class="fa fa-clock-o"></i></div>
                        <p class="contact_title">Opening Hours</p>
                        <p class="uppercase">Gulf Standard Time</p>
                        <p class="uppercase">08:00 AM – 08:00 PM</p>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3">
                    <div class="email_us s_header">
                        <div><i class="fa fa-phone"></i></div>
                        <p class="contact_title">Please call us at any time 24/7</p>
                        <p>stay in conatct with our team</p>
                        <p><a href="tel:+971 58 672 1747">+971 58 672 1747</a> (Mohsin Mughal)</p>
                        <!-- <p><a href="tel:+971 55 132 4148">+971 55 132 4148</a></p> -->
                    </div>
                </div>
                <div class="col-md-4 col-lg-4">
                    <div class="email_us s_header">
                        <div><i class="fab fa-whatsapp"></i></div>
                        <p class="contact_title">Click on number to Whatsapp</p>
                        <p class="uppercase"><a href="https://api.whatsapp.com/send?phone=+971586721747&text=Hi%20FoxMovers,%20i%20want%20to%20contact%20you%20now!">+971 58 672 1747</a> (Sunny Mirza)</p>
                        <p class="uppercase"><a href="https://api.whatsapp.com/send?phone=+971586721747&text=Hi%20FoxMovers,%20i%20want%20to%20contact%20you%20now!">+971 55 132 4148</a> (Mohsin Mughal)</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--End Header Area-->
<!--Start Slider Area -->
<section class="slider_area">

    <div class="mainmenu_area">
        <div class="container">
            <div class="row">
                <div class="col-md-9 col-lg-9">
                    <div class="mainmenu nav">
                        <nav>
                            <ul id="nav">
                                <li class="current"><a href="index.php">Home</a></li>
                                <li><a href="about-us.php">About Us</a></li>
                                <li><a href="service.php">Service</a></li>
                                <li><a href="storage-location.php">Team</a></li>
                                <li><a href="contact-us.php">Contact Us</a></li>
                                <li>
                                    <!-- <form action="process.php" class="search-form">
                                        <div class="form-group has-feedback">
                                            <label for="search" class="sr-only">Search</label>
                                            <input type="text" class="form-control" name="search" id="search" placeholder="search">
                                            <span class="glyphicon glyphicon-search form-control-feedback"></span>
                                        </div>
                                    </form> -->
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3">
                    <div class="request_code">
                        <input type="submit" value="GET A QUTE">
                    </div>
                </div>
            </div>
        </div>
    </div>

</section>
<!--End Slider Area-->