          <!-- Slider Bottom Area-->
          <!-- <section class="slider_bottom_area section_padding ">
              <div class="container">
                  <div class="row">
                      <div class="col-md-12 col-lg-12">
                          <div class="slider_bottom">
                              <div class="single_slide"><a href="#"><img src="img/slide_1.jpg" alt=""></a></div>
                              <div class="single_slide"><a href="#"><img src="img/slide_2.jpg" alt=""></a></div>
                              <div class="single_slide"><a href="#"><img src="img/slide_3.jpg" alt=""></a></div>
                              <div class="single_slide"><a href="#"><img src="img/slide_4.jpg" alt=""></a></div>
                              <div class="single_slide"><a href="#"><img src="img/slide_5.jpg" alt=""></a></div>
                              <div class="single_slide"><a href="#"><img src="img/slide_6.jpg" alt=""></a></div>
                              <div class="single_slide"><a href="#"><img src="img/slide_1.jpg" alt=""></a></div>
                              <div class="single_slide"><a href="#"><img src="img/slide_2.jpg" alt=""></a></div>
                              <div class="single_slide"><a href="#"><img src="img/slide_3.jpg" alt=""></a></div>
                              <div class="single_slide"><a href="#"><img src="img/slide_4.jpg" alt=""></a></div>
                              <div class="single_slide"><a href="#"><img src="img/slide_5.jpg" alt=""></a></div>
                              <div class="single_slide"><a href="#"><img src="img/slide_6.jpg" alt=""></a></div>
                          </div>
                      </div>
                  </div>
              </div>
          </section> -->
          <!--End Slider Bottom Area-->

          <!-- Newsletter Area -->
          <section class="newsletter_area ">
              <div class="container">
                  <div class="row">
                      <div class="col-md-6 col-lg-6">
                          <div class="signup_newsletter">
                              <p>singup for our</p>
                              <h3>newsletter</h3>
                              <form action="process.php">
                                  <input type="email" placeholder="e-mail address" required>
                                  <input type="submit" value="suscribe">
                              </form>
                          </div>
                      </div>
                  </div>
              </div>
          </section>
          <!--End Newsletter Area-->

          <!-- Footer Area  -->
          <footer class="footer_area ">
              <div class="footer_top_area  section_dark">
                  <div class="container">
                      <div class="row footer_padding_top">
                          <div class="col-md-4 col-lg-4">
                              <div class="footer_adddress s_footer">
                                  <div><i class="fa fa-home"></i></div>
                                  <p class="uppercase">address</p>
                                  <p>Behind Iranian masjid Street Number 25 villa Number 66 ,Dubai U.A.E</p>
                              </div>
                          </div>
                          <div class="col-md-4 col-lg-4 ">
                              <div class="footer_call_us s_footer">
                                  <div><i class="fa fa-phone"></i></div>
                                  <p class="uppercase">quick contact</p>
                                  <p><a href="tel:+971 58 672 1747" style="color: white;">+971 58 672 1747</a> (Mohsin Mughal)</p>
                                  <p><a href="tel:+971 55 132 4148" style="color: white;">+971 55 132 4148</a> (Sunny Mirza)</p>
                              </div>
                          </div>
                          <div class="col-md-4 col-lg-4">
                              <div class="footer_email_us s_footer">
                                  <div><i class="fa fa-envelope-o"></i></div>
                                  <p class="uppercase">Email address</p>
                                  <p>foxmovers137@gmail.com</p>
                              </div>
                          </div>
                      </div>
                      <div class="row">
                          <div class="col-md-12 col-lg-12">
                              <div class="footer_border"></div>
                          </div>
                      </div>
                      <div class="row footer_padding_bottom">
                          <div class="col-md-3 col-lg-3">
                              <div class="footer_discription">
                                  <h3>About Us</h3>
                                  <p>Fox Movers is a trustworthy Moving Company based in Dubai , UAE.
                                      We have services in Abu Dhabi, Sharjah, Dubai, and all other Emirates. </p>
                                  <div class="footer_social_bookmark">
                                      <ul>
                                          <li><a href="https://www.facebook.com/Foxmoversuaecom-105520454505937"><i class="fa fa-facebook"></i></a></li>
                                          <li><a href="https://twitter.com/Foxmovers2"><i class="fa fa-twitter"></i></a></li>
                                          <li><a href="https://www.instagram.com/foxmoveruae/"><i class="fa fa-instagram"></i></a></li>
                                          <li><a href="https://www.youtube.com/channel/UCAyQoggh5zErNScx6u9bYFA"><i class="fab fa-youtube"></i></a></li>
                                          <li><a href="mailto:foxmovers137@gmail.com"><i class="fas fa-envelope"></i></a></li>
                                      </ul>
                                  </div>
                              </div>
                          </div>
                          <div class="col-md-3 col-lg-3">
                              <div class="footer_list">
                                  <h3>our service</h3>
                                  <div class="col-md-12 col-lg-12">
                                      <ul>
                                          <li><a href="#">Residential Relocation</a></li>
                                          <li><a href="#">Commercial Relocation</a></li>
                                          <li><a href="#">Storage Service</a></li>
                                          <li><a href="#">Packing Service</a></li>
                                      </ul>
                                  </div>
                              </div>
                          </div>
                          <div class="col-md-3 col-lg-3">
                              <div class="footer_opening_time">
                                  <h3>buseness hour</h3>
                                  <p>Monday To Friday:<br>8:00 am to 8:00 pm </p>
                                  <p>Vacations:<br>All Sundays <br> All Official Holydays</p>
                              </div>
                          </div>
                          <div class="col-md-3 col-lg-3">
                              <div class="footer_list">
                                  <h3>Click on number to Whatsapp <i class="fab fa-whatsapp"></i>
</h3>
                                  <p class="uppercase">
                                      <a style="color: white;" href="https://api.whatsapp.com/send?phone=+971586721747&text=Hi%20FoxMovers,%20i%20want%20to%20contact%20you%20now!">+971 58 672 1747</a> (Sunny Mirza)
                                  </p>
                                  <p class="uppercase">
                                      <a style="color: white;" href="https://api.whatsapp.com/send?phone=+971586721747&text=Hi%20FoxMovers,%20i%20want%20to%20contact%20you%20now!">+971 55 132 4148</a> (Mohsin Mughal)
                                  </p>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
              <div class="footer_bottom_area">
                  <div class="container">
                      <div class="row">
                          <div class="col-md-6 col-lg-6">
                              <div class="footer_copyright">
                                  <p>
                                      <script>
                                          document.write(new Date().getFullYear())
                                      </script>
                                      Fox Movers All rights reserved by
                                      <a style="color: lightblue" href="https://SyedDaniyalAli.com" target="_blank">SDA</a>
                                  </p>
                              </div>
                          </div>
                          <div class="col-md-6 col-lg-6">
                              <div class="footer_menu">
                                  <nav>
                                      <ul>
                                          <li><a href="index.php">Home</a></li>
                                          <li>I</li>
                                          <li><a href="about-us.php">About Us</a></li>
                                          <li>I</li>
                                          <li><a href="service-details.php">Service</a></li>
                                          <li>I</li>
                                          <li><a href="contact-us.php">Contact Us</a></li>
                                      </ul>
                                  </nav>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </footer>
          <!--End Footer Area-->

          <!-- jquery js -->
          <script src="js/vendor/jquery-1.11.2.min.js"></script>
          <!--Bootstrap-->
          <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
          <!--Revolation Slider-->
          <script src="rs-plugin/js/jquery.themepunch.plugins.min.js"></script>
          <script src="rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
          <!--Carousel Slider-->
          <script src="js/owl.carousel.min.js"></script>
          <!--Mobile Menu Js-->
          <script src="js/jquery.slicknav.min.js"></script>
          <!--Active jQuery-->
          <script src="js/main.js"></script>
          </body>

          </html>