<?php
include('./includes_sda/sda_tables_data.php');
?>

<!DOCTYPE html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!--Responsive Meta-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--Title-->
    <title>FOX Movers</title>
    <!--Bootstrap Css-->
    <link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css" rel="stylesheet">
    <!--Font-awesome 04-->
    <!-- <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet"> -->
    <!--Font-awesome 05-->
    <script src="https://kit.fontawesome.com/35916db2f5.js" crossorigin="anonymous"></script>

    <!--Fonts Form Google Web Fonts-->
    <link href='http://fonts.googleapis.com/css?family=Lato:400,300,400italic,700,900,700italic' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Roboto:500' rel='stylesheet' type='text/css'>
    <!--Responsive Mobile Menu-->
    <link rel="stylesheet" href="css/slicknav.css" />
    <!--Revolation Slider-->
    <link href="rs-plugin/css/settings.css" rel="stylesheet">
    <!--Carousel Slider-->
    <link href="css/owl.carousel.css" rel="stylesheet">
    <!--Main Style Css-->
    <link href="style.css" rel="stylesheet">
    <!--Responsive-->
    <link href="css/responsive.css" rel="stylesheet">
    <link href="css/personal_sda.css" rel="stylesheet">


</head>