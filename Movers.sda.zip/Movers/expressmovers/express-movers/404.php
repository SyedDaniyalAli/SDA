<?php include('./includes_sda/header.php'); ?>

<body>

    <?php include('./includes_sda/navbar.php'); ?>


    <!--Start Banner Area -->
    <section class="about_page_barner_area">
        <div class="barner_content">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                        <div class="barner_text text-center">
                            <h2>404 error</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Banner Area-->
    <!--Start Not Found Area-->
    <section class="not_found_area section_padding ">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-8 col-lg-offset-2 col-md-offset-2 col-sm-12 col-xs-12">
                    <div class="not_found_page_page_content text-center">
                        <h2>sorry page not found!</h2>
                        <h1 class="error_text">404</h1>
                        <form action="process.php">
                            <input type="text" placeholder="SEARCH HERE..">
                            <button type="submit">SEARCH</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End Not Found Area -->

    <?php include('./includes_sda/footer.php'); ?>