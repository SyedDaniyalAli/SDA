<?php include('./includes_sda/header.php'); ?>


<body>

    <?php include('./includes_sda/navbar.php'); ?>


    <!--Start Slider Area-->
    <section class="about_page_barner_area">
        <div class="barner_content">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                        <div class="barner_text text-center">
                            <h2>moveing overseas</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
    <!--End Slider Area-->
    <!--Start Sercice Details Area -->
    <section class="service_details_area section_padding ">
        <div class="container">
            <div class="row">
                <div class="col-md-9 col-lg-9 col-sm-12 col-xs-12">
                    <div class="service_details_page_content">
                        <img src="img/service/service_1.jpg" alt="">
                        <h3>Moving Overseas</h3>
                        <p>Just two good ol' boys Wouldn't change if they could. Fightin' the system like a true modern day Robin Hood. All of them had hair of gold like their mother the youngest one in curls. As long as we live its you and me baby. There ain't nothin' wrong with that. Doin' it our way. There's nothing we wont try. Never heard the word impossible. This time there's no stopping us. Doin' it our way. Nothin's gonna turn us back now. Straight ahead and on the track now. We're gonna make our dreams come true. Goodbye gray sky hello blue. There's nothing can hold me when I hold you. Feels so right it cant be wrong. Rockin' and rollin' all week long.</p>
                        <div class="service_details_bottom_content">
                            <img class="alignright" src="img/service/service_2.jpg" alt="">
                            <p>Mister we could use a man like Herbert Hoover again. Maybe you and me were never meant to be. But baby think of me once in awhile. I'm at WKRP in Cincinnati! Just two good ol' boys Wouldn't change if they could. Fightin' the system like a true modern day Robin Hood. </p>
                            <ul>
                                <li>The first mate and his Skivery best to make the others comfortable in their tropic</li>
                                <li>Michael Knight a young loner on a crusade to champion the cause of the innocent</li>
                                <li>The powerless in a world of criminals who operate above the law.</li>
                                <li>You would see the biggest gift would be from me and the card attached would</li>
                                <li>These are the voyages of the Starship Enterprise</li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-sm-12 col-xs-12">
                    <div class="get_quate_sidebar">
                        <div class="s_sidebar">
                            <h3>our services</h3>
                            <ul class="quate_sidebar">
                                <li class="quate_icon_1"><a href="">moving locally or interstate</a></li>
                                <li class="quate_icon_2"><a href="">moving overseas</a></li>
                                <li class="quate_icon_3"><a href="">corporate relocation</a></li>
                                <li class="quate_icon_4"><a href="">commercial relocation</a></li>
                                <li class="quate_icon_5"><a href="">packing</a></li>
                                <li class="quate_icon_6"><a href="">storage</a></li>
                            </ul>
                            <p><a href="get-a-quate.php">GET A QUATE</a></p>
                            <div class="sidebar_img">
                                <img src="img/faq/faq_1.jpg" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Sercice Details Area-->


    <?php include('./includes_sda/footer.php'); ?>