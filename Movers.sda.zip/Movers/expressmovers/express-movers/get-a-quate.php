<?php include('./includes_sda/header.php'); ?>

<body>

    <?php include('./includes_sda/navbar.php'); ?>

    <!--Start Slider Area -->
    <section class="about_page_barner_area">
        <div class="barner_content">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                        <div class="barner_text text-center">
                            <h2>Get A Quate</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
    <!--End Slider Area-->
    <!--Start Sercice Area-->
    <section class="work_area section_padding ">
        <div class="container">
            <div class="row">
                <div class="col-md-9 col-lg-9 col-sm-12 col-xs-12">
                    <div class="contact_information_form">
                        <h3>CONTACT INFORMATION</h3>
                        <form action="process.php">
                            <div class="top_contact">
                                <div class="row">
                                    <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                        <p>First Name*<br /><input type="text" required></p>
                                    </div>
                                    <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                        <p>Last Name*<br /><input type="text" required></p>
                                    </div>
                                    <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                        <p>Email Address*<br /><input type="email" required></p>
                                    </div>
                                    <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                        <p>Phone*<br /><input type="text" required></p>
                                    </div>
                                    <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                        <p>Address<br /><input type="text"></p>
                                    </div>
                                    <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                        <p>City<br /><input type="text"></p>
                                    </div>
                                    <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                        <p>State<br /><input type="text"></p>
                                    </div>
                                    <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                        <p>Zip<br /><input type="text"></p>
                                    </div>
                                </div>
                            </div>
                            <div class="bottom_details">
                                <h3>MOVE DETAILS</h3>
                                <div class="row">
                                    <div class="col-md-7 col-lg-7 col-sm-12 col-xs-12">
                                        <p>Requested move date *<br /><input type="text" required></p>
                                    </div>
                                    <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                        <p>moving from zip *<br /><input type="text" required></p>
                                    </div>
                                    <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                        <p>describe the location *<br /><input type="text" required></p>
                                    </div>
                                    <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                        <p>moving to zip *<br /><input type="text" required></p>
                                    </div>
                                    <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                        <p>describe the location *<br /><input type="text" required></p>
                                    </div>
                                    <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                        <p>type of residence<br /><input type="text"></p>
                                    </div>
                                    <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                                        <p>storage requested ?<br /><input type="text"></p>
                                    </div>
                                </div>
                                <button type="submit">GET A QUATE</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-sm-12 col-xs-12">
                    <div class="get_quate_sidebar">
                        <div class="s_sidebar">
                            <h3>our services</h3>
                            <ul class="quate_sidebar">
                                <li class="quate_icon_1"><a href="">moving locally or interstate</a></li>
                                <li class="quate_icon_2"><a href="">moving overseas</a></li>
                                <li class="quate_icon_3"><a href="">corporate relocation</a></li>
                                <li class="quate_icon_4"><a href="">commercial relocation</a></li>
                                <li class="quate_icon_5"><a href="">packing</a></li>
                                <li class="quate_icon_6"><a href="">storage</a></li>
                            </ul>
                            <div class="sidebar_img">
                                <img src="img/get_quate/get_quate_1.jpg" alt="">
                                <img src="img/get_quate/get_quate_2.jpg" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Service Area-->

    <?php include('./includes_sda/footer.php'); ?>