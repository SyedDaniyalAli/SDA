<?php include('./includes_sda/header.php'); ?>

<body>
    <?php include('./includes_sda/navbar.php'); ?>

    <!--Start Slider Area -->
    <section class="about_page_barner_area">
        <div class="barner_content">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                        <div class="barner_text text-center">
                            <h2>About Us</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
    <!--End Slider Area-->

    <!--Start Promotions Area  -->
    <section class="promotions_area section_padding">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-lg-10 col-md-offset-1 col-lg-offset-1">
                    <div class="page_title text-center">
                        <h2>If you have questions queries contact us!</h2>
                        <p>Never heard the word impossible. This time there's no stopping us. These Happy Days are yours and mine Happy Days. Today still wanted by the government they survive as soldiers of fortune. Said Californ'y is the place you ought to be So they loaded up the truck and moved to Beverly. </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3 col-lg-3 ">
                    <div class="single_contact">
                        <div class="s_contuct_icon">
                            <i class="fa fa-map-marker"></i>
                        </div>
                        <h3>address</h3>
                        <p>09 Movers and Packers, Design <br /> Street,Victoria, Australia</p>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 ">
                    <div class="single_contact">
                        <div class="s_contuct_icon">
                            <i class="fa fa-envelope-o"></i>
                        </div>
                        <h3>e-mail</h3>
                        <p>Info@ItemMovers.Com <br /> Help@ItemMovers.Com</p>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 ">
                    <div class="single_contact">
                        <div class="s_contuct_icon">
                            <i class="fa fa-phone"></i>
                        </div>
                        <h3>phone</h3>
                        <p>+01 234 567 89 <br />+01 234 567 90</p>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 ">
                    <div class="single_contact">
                        <div class="s_contuct_icon">
                            <i class="fa fa-clock-o"></i>
                        </div>
                        <h3>working hour</h3>
                        <p>Monday To Friday : 9:00 Am to 9:00 Pm<br />Saturday : 9:00 Am to 5:00 Pm</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Promotions Area-->

    <!--Start Get in Tuch area-->
    <section class="get_in_tuch_area section_padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
                    <div class="get_in_tuch ">
                        <h3>get in touch with us</h3>
                        <div class="get_in_tuch_form">
                            <form action="process.php">
                                <div class="row">
                                    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                        <input type="text" placeholder="YOUR NAME">
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                        <input type="text" placeholder="YOUR E-MAIL ">
                                    </div>
                                    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                                        <input type="text" placeholder="YOUR PHONE NUMBER">
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <textarea name="example" id="example" cols="30" rows="10" placeholder="YOUR MESSAGE"></textarea>
                                    </div>
                                    <button type="submit">SEND MESSAGE</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Get in Tuch area-->

    <?php include('./includes_sda/footer.php'); ?>