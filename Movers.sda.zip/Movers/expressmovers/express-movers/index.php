<?php include('./includes_sda/header.php'); ?>

<body>

    <?php include('./includes_sda/navbar_with_slider.php'); ?>

    <!--Start Promotions Area -->
    <section class="promotions_area section_padding">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-lg-10 col-md-offset-1 col-lg-offset-1">
                    <div class="page_title text-center">
                        <h2>WElCOME TO FOX MOVERS</h2>
                        <p>We provide services ranging from packing and moving to storage and relocating anywhere within the UAE.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 col-lg-4 ">
                    <div class="single_promotions text-center">
                        <div class="s_promotion_icon">
                            <img src="img/track_icon.png" alt="">
                        </div>
                        <h2>we make it faster</h2>
                        <p>We also expanded the list of our happy respected customers who have done business with us since the start of our operations, or are still doing business.</p>
                    </div>
                </div>
                <div class="col-md-4 col-lg-4 ">
                    <div class="single_promotions text-center">
                        <div class="s_promotion_icon">
                            <img src="img/hand_icon.png" alt="">
                        </div>
                        <h2>save and secure move</h2>
                        <p>It is our sincerity and dignity that we assure you. Customer instructions, suggestions, comments, and enquiries are taken extremely seriously at FOX Movers. We assure you of our swift actions and response.</p>
                    </div>
                </div>
                <div class="col-md-4 col-lg-4 ">
                    <div class="single_promotions text-center">
                        <div class="s_promotion_icon">
                            <img src="img/alarm_clock_icon.png" alt="">
                        </div>
                        <h2>on time delevery</h2>
                        <p>Our staff members are highly experienced in their field and thoroughly understand the delicacy of sensitive products and how to take good care of each object while packaging, processing, loading , unloading and rearranging them.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Promotions Area-->
    <!--Start Signup Area -->
    <section class="singnup_area section_padding">
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-lg-4">
                    <div class="signup_img">
                        <img src="img/singup_area_bg.png" alt="">
                    </div>
                </div>

                <div class="col-md-8 col-lg-8">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title">GET A QUICK QUOTE</h4>
                            <p class="card-category">Get quote in minimum time</p>
                        </div>
                        <div class="card-body">
                            <form action="#" method="POST">
                                <div class="row">

                                    <input id="Cid" name="Cid" type="hidden" class="form-control">

                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label class="bmd-label-floating">Name</label>
                                            <input required id="Cname" name="Cname" type="text" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label class="bmd-label-floating">Email</label>
                                            <input required id="Cemail" name="Cemail" type="email" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label class="bmd-label-floating">Phone</label>
                                            <input required id="Cphone" name="Cphone" type="text" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="bmd-label-floating">Message</label>
                                            <input required id="Cmessage" name="Cmessage" type="text" class="form-control">
                                        </div>
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-primary pull-right">Send Request</button>
                                <div class="clearfix"></div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>
    <!--End Signup Area-->
    <!--Start Work Area -->
    <section class="work_area section_padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-12">
                    <div class="page_title">
                        <h2>why we are best form other</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 col-lg-4">
                    <div class="single_work">
                        <a href=""><img class="alignleft" src="img/24_7.png" alt=""></a>
                        <h4>24/4 Service</h4>
                        <p>We provide you the 24/7 support, we work for you not count it's day or night</p>
                    </div>
                    <div class="single_work">
                        <a href=""><img class="alignleft" src="img/track_two.png" alt=""></a>
                        <h4>over 750 vehicles</h4>
                        <p>We have too much vehicle to delivery your essential at any place anywhere in UAE</p>
                    </div>
                    <div class="single_work">
                        <a href=""><img class="alignleft" src="img/man_icon.png" alt=""></a>
                        <h4>security cleared drivers</h4>
                        <p>We check all our customers before send to you, all drivers are security cleared</p>
                    </div>
                </div>
                <div class="col-md-4 col-lg-4">
                    <div class="single_work">
                        <a href=""><img class="alignleft" src="img/map_maker.png" alt=""></a>
                        <h4>live tracking</h4>
                        <p>We give you the facility to track your parcel's location live in you phone</p>
                    </div>
                    <div class="single_work">
                        <a href=""><img class="alignleft" src="img/sms_mail.png" alt=""></a>
                        <h4>Acknowledgment alerts</h4>
                        <p>We acknowledge you about any process of your parcels on time</p>
                    </div>
                    <div class="single_work">
                        <a href=""><img class="alignleft" src="img/fire_clock.png" alt=""></a>
                        <h4>estamited delevery time</h4>
                        <p>As our system is very efficent, they are punctual to delivery before esimated time</p>
                    </div>
                </div>
                <div class="col-md-4 col-lg-4">
                    <div class="work_area_img">
                        <img src="img/work_man_two.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Work Area-->
    <!--Start Sercice Area -->
    <section class="work_area section_padding section_gray">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-12">
                    <div class="page_title text-center">
                        <h2>Service we provide</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3 col-lg-3 col-sm-6">
                    <div class="single_service">
                        <a href=""><img src="img/service_1.jpg" alt=""></a>
                        <div class="service_title">
                            <i class="fas fa-home"></i>
                            <h4><a href="#">Residential Reloc.</a></h4>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-sm-6">
                    <div class="single_service">
                        <a href=""><img src="img/service_2.jpg" alt=""></a>
                        <div class="service_title">
                            <i class="fas fa-store-alt"></i>
                            <h4><a href="#">Commercial Reloc.</a></h4>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-sm-6">
                    <div class="single_service">
                        <a href=""><img src="img/service_3.jpg" alt=""></a>
                        <div class="service_title">
                            <i class="fas fa-warehouse"></i>
                            <h4><a href="#">Storage Service</a></h4>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-sm-6">
                    <div class="single_service">
                        <a href=""><img src="img/service_4.jpg" alt=""></a>
                        <div class="service_title">
                            <i class="fas fa-box-open"></i>
                            <h4><a href="#">Packing Service</a></h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Service Area-->
    <!--Our Process Area -->
    <section class="process_area section_padding ">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-12">
                    <div class="page_title text-center">
                        <h2>Our Process</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="process_area_menu">
                    <ul>
                        <li>
                            <a href="#"><img src="img/process_1.png" alt=""></a>
                            <p class="process_title">book our service</p>
                        </li>
                        <li>
                            <a href="#"><img src="img/process_2.png" alt=""></a>
                            <p class="process_title">we pack our things</p>
                        </li>
                        <li>
                            <a href="#"><img src="img/process_3.png" alt=""></a>
                            <p class="process_title">we move you things</p>
                        </li>
                        <li>
                            <a href="#"><img src="img/process_4.png" alt=""></a>
                            <p class="process_title">delevery you safely</p>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!--Our Process Area-->
    <!--Our Great Team Area  -->
    <section class="process_area section_padding section_gray">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-12">
                    <div class="page_title text-center">
                        <h2>Our Responsible Team</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3 col-lg-3 col-sm-6">
                    <div class="single_team">
                        <a href=""><img src="img/team_1.jpg" alt=""></a>
                        <div class="team_discription">
                            <h3>Sunny Mirza</h3>
                            <p>ceo/founder</p>
                        </div>
                    </div>
                </div>
                <!-- <div class="col-md-3 col-lg-3 col-sm-6">
                    <div class="single_team">
                        <a href=""><img src="img/team_2.jpg" alt=""></a>
                        <div class="team_discription">
                            <h3></h3>
                            <p>driver</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-sm-6">
                    <div class="single_team">
                        <a href=""><img src="img/team_3.jpg" alt=""></a>
                        <div class="team_discription">
                            <h3></h3>
                            <p>delevery boy</p>
                        </div>
                    </div>
                </div> -->
                <div class="col-md-3 col-lg-3 col-sm-6">
                    <div class="single_team">
                        <a href=""><img src="img/team_4.jpg" alt=""></a>
                        <div class="team_discription">
                            <h3>Mohsin Mughal</h3>
                            <p>manager</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Our Great Team Area-->
    <!--Client Discription Area  -->
    <section class="client_discription_area section_padding ">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-12">
                    <div class="page_title text-center">
                        <h2>what out customer say about us</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 col-lg-6">
                    <div class="single_client">
                        <div class="client_img">
                            <img src="img/client_discription_1.png" alt="">
                        </div>
                        <div class="client_discription">
                            <h5>Syed Daniyal Ali</h5>
                            <p class="client_address">Owner of SDA company</p>
                            <p>Thank you for being a friend. Travelled down the road and back again. Your heart is true you're a pal and a confidant. Movin' on up to the east side. We finally got a piece of the pie. </p>
                            <div class="rating_area">
                                <p class="text-left">100% recomended</p>
                                <div class="ratting text-right">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6">
                    <div class="single_client">
                        <div class="client_img">
                            <img src="img/client_discription_2.png" alt="">
                        </div>
                        <div class="client_discription">
                            <h5>Syed Muhammad Farhan Ali Raza Zaidi</h5>
                            <p class="client_address">Manager at world travelers</p>
                            <p>The weather started getting rough - the tiny ship was tossed. If not for the courage of the fearless crew the Minnow would be lost. the Minnow would be lost.</p>
                            <div class="rating_area">
                                <p class="text-left">100% recomended</p>
                                <div class="ratting text-right">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Client Discription Area-->

    <?php include('./includes_sda/footer.php'); ?>