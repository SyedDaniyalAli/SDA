<?php include('./includes_sda/header.php'); ?>

<body>

    <?php include('./includes_sda/navbar.php'); ?>


    <!--Start Slider Area -->
    <section class="about_page_barner_area">
        <div class="barner_content">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
                        <div class="barner_text text-center">
                            <h2>frequently asked questions</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Slider Area-->
    <!--Start Sercice Area -->
    <section class="work_area section_padding ">
        <div class="container">
            <div class="row">
                <div class="col-md-9 col-lg-9 col-sm-12 col-xs-12">
                    <div class="faq_page_page_content">
                        <h2>frequently asked questions</h2>
                        <div class="faq_menu">
                            <ul>
                                <li>
                                    <div class="single_faq">
                                        <h3><i class="fa fa-plus active"></i>How do I book a move with express movers? </h3>
                                        <p class="active">Flying away on a wing and a prayer. Who could it be? Believe it or not its just me. Love exciting and new. Come aboard were expecting you. Love life's sweetest reward Let it flow it floats back to you. Now the world don't move to the beat of just one drum. What might be right for you may not be right for some. So this is the tale of our castaways.</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="single_faq">
                                        <h3><i class="fa fa-plus"></i>My Family wishes to get our car loaded in our presence. Is it feasible?</h3>
                                        <p>Flying away on a wing and a prayer. Who could it be? Believe it or not its just me. Love exciting and new. Come aboard were expecting you. Love life's sweetest reward Let it flow it floats back to you. Now the world don't move to the beat of just one drum. What might be right for you may not be right for some. So this is the tale of our castaways.</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="single_faq">
                                        <h3><i class="fa fa-plus"></i>What can I expect when the mover comes to my home to do an estimate?</h3>
                                        <p>Flying away on a wing and a prayer. Who could it be? Believe it or not its just me. Love exciting and new. Come aboard were expecting you. Love life's sweetest reward Let it flow it floats back to you. Now the world don't move to the beat of just one drum. What might be right for you may not be right for some. So this is the tale of our castaways.</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="single_faq">
                                        <h3><i class="fa fa-plus"></i>What information must the moving company provide?</h3>
                                        <p>Flying away on a wing and a prayer. Who could it be? Believe it or not its just me. Love exciting and new. Come aboard were expecting you. Love life's sweetest reward Let it flow it floats back to you. Now the world don't move to the beat of just one drum. What might be right for you may not be right for some. So this is the tale of our castaways.</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="single_faq">
                                        <h3><i class="fa fa-plus"></i>My move date changed. What should I do? </h3>
                                        <p>Flying away on a wing and a prayer. Who could it be? Believe it or not its just me. Love exciting and new. Come aboard were expecting you. Love life's sweetest reward Let it flow it floats back to you. Now the world don't move to the beat of just one drum. What might be right for you may not be right for some. So this is the tale of our castaways.</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="single_faq">
                                        <h3><i class="fa fa-plus"></i>What am I not allowed to bring with me on my move? </h3>
                                        <p>Flying away on a wing and a prayer. Who could it be? Believe it or not its just me. Love exciting and new. Come aboard were expecting you. Love life's sweetest reward Let it flow it floats back to you. Now the world don't move to the beat of just one drum. What might be right for you may not be right for some. So this is the tale of our castaways.</p>
                                    </div>
                                </li>
                                <li>
                                    <div class="single_faq">
                                        <h3><i class="fa fa-plus"></i>How soon before I move should I call the movers?</h3>
                                        <p>Flying away on a wing and a prayer. Who could it be? Believe it or not its just me. Love exciting and new. Come aboard were expecting you. Love life's sweetest reward Let it flow it floats back to you. Now the world don't move to the beat of just one drum. What might be right for you may not be right for some. So this is the tale of our castaways.</p>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 col-sm-12 col-xs-12">
                    <div class="get_quate_sidebar">
                        <div class="s_sidebar">
                            <h3>our services</h3>
                            <ul class="quate_sidebar">
                                <li class="quate_icon_1"><a href="">moving locally or interstate</a></li>
                                <li class="quate_icon_2"><a href="">moving overseas</a></li>
                                <li class="quate_icon_3"><a href="">corporate relocation</a></li>
                                <li class="quate_icon_4"><a href="">commercial relocation</a></li>
                                <li class="quate_icon_5"><a href="">packing</a></li>
                                <li class="quate_icon_6"><a href="">storage</a></li>
                            </ul>
                            <p><a href="get-a-quate.php">GET A QUATE</a></p>
                            <div class="sidebar_img">
                                <img src="img/faq/faq_1.jpg" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--End Service Area-->
    <?php include('./includes_sda/footer.php'); ?>