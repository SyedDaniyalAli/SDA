<?php include('sda_tables_data.php'); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../assets/img/favicon.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>
        Admin panel
    </title>
    <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
    <!-- CSS Files -->
    <link href="../assets/css/material-dashboard.css?v=2.1.2" rel="stylesheet" />
    <link href="../assets/css/personal.css?" rel="stylesheet" />

    <!-- Custom styles for this page FOR TABLES -->
    <link href="../assets/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

    <!-- JS~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ -->

    <!--  Plugin for Sweet Alert js-->
    <!-- <script src="../assets/js/plugins/sweetalert2.js"></script> -->
    <script src="../assets/sweetalert/sweetalert.min.js"></script>
    <script src="../assets/sweetalert/sweetalert.js"></script>
    <!--  Plugin for Sweet Alert css -->
    <link href="../assets/sweetalert/sweetalert.css" rel="stylesheet">



    <!-- Google and Micosoft ajax jQuery -->
    <script src="../assets/jquery_ajax/google.jquery.min.js"></script>
    <script src="../assets/jquery_ajax/microsoft.jquery-3.4.1.min.js"></script>
    <!-- for online -->
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script> -->


    <!--  Notifications Plugin    -->
    <script src="../assets/js/plugins/bootstrap-notify.js"></script>
    <!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
    <!-- <script src="../assets/js/material-dashboard.js?v=2.1.2" type="text/javascript"></script> -->

</head>


<script>
    // Initialized the cookies
    document.cookie = "deleted_value=" + "null";
</script>