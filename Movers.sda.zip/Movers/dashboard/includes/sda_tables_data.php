<?php

class SDA_Movers
{
    private $con;
    private $DB_SERVER="localhost";
    private $DB_USER="root";
    private $DB_PASS="";
    private $DB_NAME="SDAmoversDB";

    // Constructor=======================================================================================================
    function __construct()
    {
        $this->con = new mysqli($this->DB_SERVER, $this->DB_USER, $this->DB_PASS, $this->DB_NAME);
        // Check connection
        if (mysqli_connect_errno()) {
            echo "Failed to connect to MySQL: " . mysqli_connect_error();
            exit();
        }
    }


    // Users=============================================================================================================
    function select_user($id)
    {   
        $tmp = array();

        if($id==NULL){

            $stmt = $this->con->query("select * from users");
            while($row = mysqli_fetch_array($stmt))
            {
                array_push($tmp, $row);
            }
            return $tmp;

        }else{

            $stmt = $this->con->query("select * from users where id = $id");
            while($row = mysqli_fetch_array($stmt))
            {
                array_push($tmp, $row);
            }
            return $tmp;
        }
    }

    function check_if_user_exist($u_name, $email, $passwd)
    {   
        if($u_name!=NULL){
            $stmt = $this->con->query("select * from users where u_name='$u_name' and pass='$passwd'");
            if($stmt->num_rows > 0)
            {
                return 1;
            }
            else
            {
                return 0;
            }

        }else if($email!=NULL){
            $stmt = $this->con->query("select * from users where email='$email' and pass='$passwd'");
            if($stmt->num_rows > 0)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }else{
            return 0;
        }
    }

    function add_user($name, $email, $passwd)
    {
        $st = $this->con->prepare("insert into users(u_name,email,pass) values(?,?,?)");
        $st->bind_param("sss", $name, $email, $passwd);
        return $st->execute();
    }

    function update_user($name, $email, $passwd, $id)
    {
        $st = $this->con->prepare("update users set u_name=?,email=?,pass=? where id=?");
        $st->bind_param("sssi", $name, $email, $passwd, $id);
        return $st->execute();
    }

    function del_user($id)
    {
        $st = $this->con->prepare("delete from users where id=?");
        $st->bind_param("i", $id);
        return $st->execute();
    }
    // Users End==========================================================================================================

    // Contacts===========================================================================================================
    function select_contact($id)
    {   
        $tmp = array();

        if($id==NULL){

            $stmt = $this->con->query("select * from contact");
            while($row = mysqli_fetch_array($stmt))
            {
                array_push($tmp, $row);
            }
            return $tmp;

        }else{

            $stmt = $this->con->query("select * from contact where id = $id");
            while($row = mysqli_fetch_array($stmt))
            {
                array_push($tmp, $row);
            }
            return $tmp;
        }
    }

    function add_contact($name, $phone, $email, $message)
    {
        $st = $this->con->prepare("insert into contact(name,phone,email,message) values(?,?,?,?)");
        $st->bind_param("ssss", $name, $phone, $email, $message);
        return $st->execute();
    }

    function update_contact($name,$phone, $email, $message, $id)
    {
        $st = $this->con->prepare("update contact set name=?,phone=?,email=?,message=? where id=?");
        $st->bind_param("ssssi", $name, $phone, $email, $message, $id);
        return $st->execute();
    }

    function del_contact($id)
    {
        $st = $this->con->prepare("delete from contact where id=?");
        $st->bind_param("i", $id);
        return $st->execute();
    }
    // Contacts End=======================================================================================================

    // Subscriptions======================================================================================================
    function select_subscription($id)
    {   
        $tmp = array();

        if($id==NULL){

            $stmt = $this->con->query("select * from email_subscriptions");
            while($row = mysqli_fetch_array($stmt))
            {
                array_push($tmp, $row);
            }
            return $tmp;

        }else{

            $stmt = $this->con->query("select * from email_subscriptions where id = $id");
            while($row = mysqli_fetch_array($stmt))
            {
                array_push($tmp, $row);
            }
            return $tmp;
        }
    }

    function add_subscription($email)
    {
        $st = $this->con->prepare("insert into email_subscriptions(email) values(?)");
        $st->bind_param("s", $email);
        return $st->execute();
    }

    function update_subscription($email, $id)
    {
        $st = $this->con->prepare("update email_subscriptions set email=? where id=?");
        $st->bind_param("si", $email, $id);
        return $st->execute();
    }

    function del_subscription($id)
    {
        $st = $this->con->prepare("delete from email_subscriptions where id=?");
        $st->bind_param("i", $id);
        return $st->execute();
    }
    // Subscriptions End==================================================================================================

    // Images=============================================================================================================
    function select_image($id)
    {   
        $tmp = array();

        if($id==NULL){

            $stmt = $this->con->query("select * from images");
            while($row = mysqli_fetch_array($stmt))
            {
                array_push($tmp, $row);
            }
            return $tmp;

        }else{

            $stmt = $this->con->query("select * from images where id = $id");
            while($row = mysqli_fetch_array($stmt))
            {
                array_push($tmp, $row);
            }
            return $tmp;
        }
    }

    function add_image($img_name, $img_alt, $path, $img_desc)
    {
        $st = $this->con->prepare("insert into images(img_name,img_alt,path,img_desc) values(?,?,?,?)");
        $st->bind_param("ssss", $img_name, $img_alt, $path, $img_desc);
        return $st->execute();
    }

    function update_image($img_name, $img_alt, $path, $img_desc, $id)
    {
        $st = $this->con->prepare("update images set img_name=?,img_alt=?,path=?,img_desc=? where id=?");
        $st->bind_param("ssssi", $img_name, $img_alt, $path, $img_desc, $id);
        return $st->execute();
    }

    function del_image($id)
    {
        $st = $this->con->prepare("delete from images where id=?");
        $st->bind_param("i", $id);
        return $st->execute();
    }
    // Images End=========================================================================================================

    // Orders=============================================================================================================
    function select_order($id)
    {   
        $tmp = array();

        if($id==NULL){

            $stmt = $this->con->query("select * from orders");
            while($row = mysqli_fetch_array($stmt))
            {
                array_push($tmp, $row);
            }
            return $tmp;

        }else{

            $stmt = $this->con->query("select * from orders where id = $id");
            while($row = mysqli_fetch_array($stmt))
            {
                array_push($tmp, $row);
            }
            return $tmp;
        }
    }

    function add_order($orderid, $name,	$phone,	$email, $service, $areatype, $packagetype, $pickup,	$dropout, $date, $description, $status, $read_status)
    {
        $st = $this->con->prepare("insert into orders(orderid,name,phone,email,service,areatype,packagetype,pickup,dropout,date,description,status,read_status) values(?,?,?,?,?,?,?,?,?,?,?,?,?)");
        $st->bind_param("sssssssssssss", $orderid, $name,	$phone,	$email, $service, $areatype, $packagetype, $pickup,	$dropout, $date, $description, $status, $read_status);
        return $st->execute();
    }

    function update_order($orderid, $name,	$phone,	$email, $service, $areatype, $packagetype, $pickup,	$dropout, $date, $description, $status, $read_status, $id)
    {
        $st = $this->con->prepare("update orders set orderid=?,name=?,phone=?,email=?,service=?,areatype=?,packagetype=?,pickup=?,dropout=?,date=?,description=?,status=?,read_status=? where id=?");
        $st->bind_param("sssssssssssssi", $orderid, $name, $phone, $email, $service, $areatype, $packagetype, $pickup, $dropout, $date, $description, $status, $read_status, $id);
        return $st->execute();
    }

    function del_order($id)
    {
        $st = $this->con->prepare("delete from orders where id=?");
        $st->bind_param("i", $id);
        return $st->execute();
    }
    // Orders End=========================================================================================================

    
    // Seo================================================================================================================
    function select_seo($id)
    {   
        $tmp = array();

        if($id==NULL){

            $stmt = $this->con->query("select * from seo");
            while($row = mysqli_fetch_array($stmt))
            {
                array_push($tmp, $row);
            }
            return $tmp;

        }else{

            $stmt = $this->con->query("select * from users seo where id = $id");
            while($row = mysqli_fetch_array($stmt))
            {
                array_push($tmp, $row);
            }
            return $tmp;
        }
    }

    function add_seo($meta_tag, $meta_title, $meta_dec,	$meta_content)
    {
        $st = $this->con->prepare("insert into seo(meta_tag,meta_title,meta_dec,meta_content) values(?,?,?,?)");
        $st->bind_param("ssss", $meta_tag, $meta_title, $meta_dec,	$meta_content);
        return $st->execute();
    }

    function update_seo($meta_tag, $meta_title, $meta_dec,	$meta_content, $id)
    {
        $st = $this->con->prepare("update seo set meta_tag=?,meta_title=?,meta_dec=?,meta_content=? where id=?");
        $st->bind_param("ssssi", $meta_tag, $meta_title, $meta_dec,	$meta_content, $id);
        return $st->execute();
    }

    function del_seo($id)
    {
        $st = $this->con->prepare("delete from seo where id=?");
        $st->bind_param("i", $id);
        return $st->execute();
    }
    // Seo End============================================================================================================
}

// $cla = new SDA_Movers();
// $check=$cla->select_seo(2);

// if($check>0)
// {
//     echo "Updated";
// }
// else
// {
//     echo "Failed";
// }

// echo $cla->check_if_user_exist(null,"sda","123");