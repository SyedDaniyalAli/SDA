<?php

if (isset($_POST['logbtn1']) || isset($_POST['logbtn2'])) {

    session_unset();
    session_destroy();
    header('location:index.php');
    // echo "<script> md.showNotification('bottom', 'center', 'Logout Successfully','success'); </script>";
}



?>

<script>
    $(function() {
        var sPath = window.location.pathname;
        var sPage = sPath.substring(sPath.lastIndexOf('/') + 1);
        $('a[href="' + './' + sPage + '"]').parent().addClass('active');
    });
</script>

<?php require('../assets/materialcharts/materialcharts.php'); ?>

<div class="wrapper ">
    <div class="sidebar" data-color="purple" data-background-color="white" data-image="../assets/img/sidebar-1.jpg">
        <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

        Tip 2: you can also add an image using data-image tag
        -->
        <div class="logo"><a href="#" class="simple-text logo-normal">
                Admin Panel
            </a></div>
        <div class="sidebar-wrapper">
            <ul class="nav">
                <li class="nav-item">
                    <a class="nav-link" id="#dashboard" href="./dashboard.php">
                        <i class="material-icons">dashboard</i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li class="nav-item ">
                    <a class="nav-link" href="./admin.php">
                        <i class="material-icons">person</i>
                        <p>User Profile</p>
                    </a>
                </li>
                <li class="nav-item ">
                    <a class="nav-link" href="./contacts.php">
                        <i class="material-icons">content_paste</i>
                        <p>contacts</p>
                    </a>
                </li>
                <li class="nav-item ">
                    <a class="nav-link" href="./subscriptions.php">
                        <i class="material-icons">library_books</i>
                        <p>Subscriptions</p>
                    </a>
                </li>
                <li class="nav-item ">
                    <a class="nav-link" href="./images.php">
                        <i class="material-icons">bubble_chart</i>
                        <p>Images</p>
                    </a>
                </li>

                <li class="nav-item ">
                    <a class="nav-link" href="./orders.php">
                        <i class="material-icons">notifications</i>
                        <p>Orders</p>
                    </a>
                </li>

                <li class="nav-item ">
                    <form method="POST" id="logoutForm_D">
                        <a class="nav-link">
                            <i class="material-icons">logout</i>
                            <p class="nav" name="log1">
                                <label for="log1">Logout</label>
                            </p>
                            <input type="submit" name="logbtn1" id="log1" style="display: none" />
                        </a>
                    </form>
                </li>

            </ul>
        </div>
    </div>
    <div class="main-panel">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
            <div class="container-fluid">
                <div class="navbar-wrapper">
                    <a class="navbar-brand" href="javascript:;">FOX Movers</a>
                </div>

                <!-- <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="navbar-toggler-icon icon-bar"></span>
                    <span class="navbar-toggler-icon icon-bar"></span>
                    <span class="navbar-toggler-icon icon-bar"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-end">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="javascript:;">
                                <i class="material-icons">dashboard</i>
                                <p class="d-lg-none d-md-block">
                                    Stats
                                </p>
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="material-icons">notifications</i> -->
                                <!-- <span class="notification">5</span> -->
                                <!-- <p class="d-lg-none d-md-block">
                                    Some Actions
                                </p>
                            </a> -->
                            <!-- <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                                    <a class="dropdown-item" href="#">Mike John responded to your email</a>
                                    <a class="dropdown-item" href="#">You have 5 new tasks</a>
                                    <a class="dropdown-item" href="#">You're now friend with Andrew</a>
                                    <a class="dropdown-item" href="#">Another Notification</a>
                                    <a class="dropdown-item" href="#">Another One</a>
                                </div> -->
                        <!-- </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link" href="javascript:;" id="navbarDropdownProfile" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="material-icons">person</i>
                                <p class="d-lg-none d-md-block">
                                    Account
                                </p>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownProfile">
                                <a class="dropdown-item" href="#">Profile</a>
                                <a class="dropdown-item" href="#">Settings</a>
                                <div class="dropdown-divider"></div>
                                <form method="POST" id="logoutForm_M">
                                    <a class="dropdown-item" name="log2">
                                        <label for="log2">Logout</label>
                                        <input type="submit" name="logbtn2" id="log2" style="display: none" />
                                    </a>
                                </form>
                            </div>
                        </li>
                    </ul>
                </div> -->
            </div>
        </nav>
        <!-- End Navbar -->

        