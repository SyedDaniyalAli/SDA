<?php

include('../includes/sda_tables_data.php');
session_start();


$u_name=$_POST["username"];
$pass=$_POST["password"];

$DB = new SDA_Movers();

$username_and_pass = $DB->check_if_user_exist($u_name,NULL,$pass);
$email_and_pass = $DB->check_if_user_exist(NULL,$u_name,$pass);


// if record found
    if ($username_and_pass || $email_and_pass) {

        $_SESSION['sign_in_uname']=$u_name;
        $_SESSION['sign_in_pass']=$pass;
        echo 1;

    } else {
        echo 0;
        session_unset();
        session_destroy();
    }

?>