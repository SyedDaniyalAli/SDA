<?php

include('../includes/sda_tables_data.php');
session_start();


$Cname=$_POST["Cname"];
$Cemail=$_POST["Cemail"];
$Cphone=$_POST["Cphone"];
$Cmessage=$_POST["Cmessage"];
$Cid=$_POST["Cid"];



$DB = new SDA_Movers();

$check = $DB->update_contact($Cname, $Cphone, $Cemail, $Cmessage, $Cid);


// if record found
    if ($check) {

        echo '<script> sessionStorage.setItem("c_msg","1");</script>';

        echo "<script> window.history.go(-1);</script>";

    } else {
        echo '<script> sessionStorage.setItem("c_msg","0");</script>';
        echo "<script> window.history.go(-1);</script>";
    }
?>