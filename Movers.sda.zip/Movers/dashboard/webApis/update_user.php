<?php

include('../includes/sda_tables_data.php');
session_start();


$u_name=$_POST["Uusername"];
$email=$_POST["Uemail"];
$pass=$_POST["Upassword"];
$Uid=$_POST["Uid"];


$DB = new SDA_Movers();

$check = $DB->update_user($u_name, $email, $pass, $Uid);


// if record found
    if ($check) {

        echo '<script> sessionStorage.setItem("c_msg","1");</script>';

        echo "<script> window.history.go(-1);</script>";

    } else {
        echo '<script> sessionStorage.setItem("c_msg","0");</script>';
        echo "<script> window.history.go(-1);</script>";
    }
?>