<?php

include('../includes/sda_tables_data.php');
session_start();


$u_name=$_POST["username"];
$email=$_POST["email"];
$pass=$_POST["password"];

$DB = new SDA_Movers();

$check = $DB->add_user($u_name, $email, $pass);


// if record found
    if ($check) {

        echo '<script> sessionStorage.setItem("c_msg","1");</script>';

        echo "<script> window.history.go(-1);</script>";

    } else {
        echo '<script> sessionStorage.setItem("c_msg","0");</script>';
        echo "<script> window.history.go(-1);</script>";
    }
?>