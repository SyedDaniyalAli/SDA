<?php

include('../includes/sda_tables_data.php');
session_start();

$Oid=$_POST["Oid"];
$Oorder_id=$_POST["Oorder_id"];
$Oname=$_POST["Oname"];
$Oemail=$_POST["Oemail"];
$Ophone=$_POST["Ophone"];
$Oservices=$_POST["Oservices"];
$Oarea_type=$_POST["Oarea_type"];
$Opkg_type=$_POST["Opkg_type"];
$Opick_up=$_POST["Opick_up"];
$Odrop_out=$_POST["Odrop_out"];
$Odate=$_POST["Odate"];
$Odec=$_POST["Odec"];
$Ostatus=$_POST["Ostatus"];
$Oread_status=$_POST["Oread_status"];


$DB = new SDA_Movers();

$check = $DB->update_order($Oorder_id, $Oname, $Ophone, $Oemail, $Oservices , $Oarea_type, $Opkg_type, $Opick_up, $Odrop_out, $Odate, $Odec, $Ostatus, $Oread_status, $Oid);


// if record found
    if ($check) {

        echo '<script> sessionStorage.setItem("c_msg","1");</script>';

        echo "<script> window.history.go(-1);</script>";

    } else {
        echo '<script> sessionStorage.setItem("c_msg","0");</script>';
        echo "<script> window.history.go(-1);</script>";
    }
?>