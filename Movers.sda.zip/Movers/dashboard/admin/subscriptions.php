<!-- Header -->
<?php include('../includes/header.php'); ?>

<?php

session_start();
$uname = $_SESSION['sign_in_uname'];
$pass = $_SESSION['sign_in_pass'];

if (strlen($_SESSION['sign_in_uname']) >= 1) {
    $DB = new SDA_Movers();
    $records = $DB->select_subscription(NULL);
} else {
    header('location:index.php');
}
?>

<script>
    function del_sub(value) {
        document.cookie = "deleted_value=" + value;
        swal({
                title: "Are you sure?",
                text: "You will not be able to recover this record!",
                type: "warning",
                showCancelButton: true,
                confirmButtonClass: "btn-danger",
                confirmButtonText: "Yes, delete it!",
                cancelButtonText: "No, cancel plx!",
                closeOnConfirm: false,
                closeOnCancel: false
            },
            function(isConfirm) {
                if (isConfirm) {

                    <?php
                    $key_value = $_COOKIE["deleted_value"];
                    if ($key_value != 0) {
                        $DB->del_subscription($key_value);
                        echo "location.reload();";
                    }
                    ?>

                    swal("Deleted!", "Your record has been deleted.", "success");
                } else {
                    swal("Cancelled", "Your record is safe :)", "error");
                }
            });
    }
</script>

<!-- Body -->

<Body class="body">
    <!-- Nav -->
    <?php include('../includes/navbar.php'); ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title ">All Subscriptions</h4>
                            <p class="card-category">you can see all subscriptions here</p>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover" id="dataTable">
                                    <thead class="text-primary">
                                        <th>
                                            ID
                                        </th>
                                        <th>
                                            Email
                                        </th>
                                        <th>
                                            Delete
                                        </th>
                                    </thead>
                                    <tbody>
                                        <?php
                                        foreach ($records as $record) {
                                        ?>
                                            <tr>
                                                <td>
                                                    <?php echo $record["id"] ?>
                                                </td>
                                                <td>
                                                    <?php echo $record["email"] ?>
                                                </td>
                                                <td class="text-danger">
                                                    <button type=" button" onclick="del_sub(this.value);" value="<?php echo $record["id"] ?>" id="del_btns" rel="tooltip" title="Remove" class="btn btn-danger btn-link btn-sm">
                                                        <i class="material-icons">close</i>
                                                    </button>
                                                </td>
                                            </tr>

                                        <?php
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


</Body>








<!-- Footer -->
<?php include('../includes/footer.php'); ?>