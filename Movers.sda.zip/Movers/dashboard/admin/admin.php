<!-- Header -->
<?php include('../includes/header.php'); ?>

<?php

session_start();
$uname = $_SESSION['sign_in_uname'];
$pass = $_SESSION['sign_in_pass'];

if (strlen($_SESSION['sign_in_uname']) >= 1) {
    $DB = new SDA_Movers();
    $records = $DB->select_user(NULL);
} else {
    header('location:index.php');
}


?>

<!-- Body -->

<Body class="body">
    <!-- Nav -->
    <?php include('../includes/navbar.php'); ?>


    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title">Admins Profile</h4>
                            <p class="card-category">update your credentials</p>
                        </div>
                        <div class="card-body">
                            <form action="../webApis/update_user.php" method="POST">
                                <div class="row">

                                    <input id="Uid" name="Uid" type="hidden" class="form-control">

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="bmd-label-floating">Email</label>
                                            <input id="Uemail" required name="Uemail" type="email" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="bmd-label-floating">Username</label>
                                            <input id="Uusername" required name="Uusername" type="text" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="bmd-label-floating">Password</label>
                                            <input required id="Upassword" name="Upassword" type="text" class="form-control">
                                        </div>
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-primary pull-right">Update</button>
                                <div class="clearfix"></div>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title">Add Admins</h4>
                            <p class="card-category">add new admins</p>
                        </div>
                        <div class="card-body">
                            <form action="../webApis/add_user.php" method="POST">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="bmd-label-floating">Email</label>
                                            <input required type="email" name="email" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="bmd-label-floating">Username</label>
                                            <input required name="username" type="text" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="bmd-label-floating">Password</label>
                                            <input required name="password" type="text" class="form-control">
                                        </div>
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-primary pull-right">Add new</button>
                                <div class="clearfix"></div>
                            </form>
                        </div>
                    </div>
                </div>


                <div class="col-md-4">
                    <div class="card card-profile">
                        <div class="card-avatar">
                            <a href="javascript:;">
                                <img class="img" src="../assets/img/faces/admin.jpeg" />
                            </a>
                        </div>
                        <div class="card-body">
                            <h6 class="card-category text-gray">CEO / Co-Founder</h6>
                            <h4 class="card-title">Mohsin Mughal</h4>
                            <p class="card-description">
                                Don't be scared of the truth because we need to restart the human foundation in truth And I love you like Kanye loves Kanye I love Rick Owens’ bed design but the back is...
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title ">Current Admins</h4>
                            <p class="card-category">here are the admin of this panel</p>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover" id="dataTable">
                                    <thead class=" text-primary">
                                        <th>
                                            ID
                                        </th>
                                        <th>
                                            User Name
                                        </th>
                                        <th>
                                            Email
                                        </th>
                                        <th>
                                            Password
                                        </th>
                                        <th>
                                            Update
                                        </th>
                                        <th>
                                            Delete
                                        </th>
                                    </thead>
                                    <tbody id="dataTableBody">
                                        <?php
                                        foreach ($records as $record) {
                                        ?>
                                            <tr>
                                                <td>
                                                    <?php echo $record["id"] ?>
                                                </td>
                                                <td>
                                                    <?php echo $record["u_name"] ?>
                                                </td>
                                                <td>
                                                    <?php echo $record["email"] ?>
                                                </td>
                                                <td>
                                                    <?php echo $record["pass"] ?>
                                                </td>
                                                <td class="text-primary">
                                                    <label class="text-primary" for="<?php echo $record["id"] ?>">Edit</a>
                                                        <input type="button" onclick="fill_input_labels( '<?php echo $record['email'] ?>' , '<?php echo $record['u_name'] ?>' , '<?php echo $record['pass'] ?>' , '<?php echo $record['id'] ?>' );" id="<?php echo $record["id"] ?>" value="<?php echo $record["id"] ?>" style="display: none;" />
                                                </td>
                                                <td>

                                                    <button type=" button" onclick="del_sub(this.value);" value="<?php echo $record["id"] ?>" id="del_btns" rel="tooltip" title="Remove" class="btn btn-danger btn-link btn-sm">
                                                        <i class="material-icons">close</i>
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</Body>


<script>
    // Clear all fileds
    document.getElementById("Uemail").value = "";
    document.getElementById("Uusername").value = "";
    document.getElementById("Upassword").value = "";
    document.getElementById("Uid").value = "";


    // Show msg
    var msg = sessionStorage.getItem("c_msg");

    if (msg == "1") {
        swal('Success');
        sessionStorage.setItem("c_msg", "");
    } else if (msg == "0") {
        swal('Failed');
        sessionStorage.setItem("c_msg", "");

    }


    // Delete data
    function del_sub(value) {
        document.cookie = "deleted_value=" + value;
        swal({
                title: "Are you sure?",
                text: "You will not be able to recover this record!",
                type: "warning",
                showCancelButton: true,
                confirmButtonClass: "btn-danger",
                confirmButtonText: "Yes, delete it!",
                cancelButtonText: "No, cancel plx!",
                closeOnConfirm: false,
                closeOnCancel: false
            },
            function(isConfirm) {
                if (isConfirm) {

                    <?php
                    $key_value = $_COOKIE["deleted_value"];
                    if ($key_value != 0) {
                        $DB->del_user($key_value);
                        echo "history.go(0);";
                    }
                    ?>

                    swal("Deleted!", "Your record has been deleted.", "success");
                } else {
                    swal("Cancelled", "Your record is safe :)", "error");
                }
            });
    }

    // Fill out the form
    function fill_input_labels(email, username, password, id) {

        document.getElementById("Uemail").value = email;
        document.getElementById("Uusername").value = username;
        document.getElementById("Upassword").value = password;
        document.getElementById("Uid").value = id;

    }
</script>







<!-- Footer -->
<?php include('../includes/footer.php'); ?>