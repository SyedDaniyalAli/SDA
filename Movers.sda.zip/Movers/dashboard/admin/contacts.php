<!-- Header -->
<?php include('../includes/header.php'); ?>


<?php

session_start();
$uname = $_SESSION['sign_in_uname'];
$pass = $_SESSION['sign_in_pass'];

if (strlen($_SESSION['sign_in_uname']) >= 1) {
    $DB = new SDA_Movers();
    $records = $DB->select_contact(NULL);
} else {
    header('location:index.php');
}

?>

<!-- Body -->

<Body class="body">
    <!-- Nav -->
    <?php include('../includes/navbar.php'); ?>


    <div class="content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title">Update Contacts</h4>
                            <p class="card-category">update your contacts</p>
                        </div>
                        <div class="card-body">
                            <form action="../webApis/update_contact.php" method="POST">
                                <div class="row">

                                    <input id="Cid" name="Cid" type="hidden" class="form-control">

                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label class="bmd-label-floating">Name</label>
                                            <input required id="Cname" name="Cname" type="text" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label class="bmd-label-floating">Email</label>
                                            <input required id="Cemail" name="Cemail" type="email" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <label class="bmd-label-floating">Phone</label>
                                            <input required id="Cphone" name="Cphone" type="text" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="bmd-label-floating">Message</label>
                                            <input required id="Cmessage" name="Cmessage" type="text" class="form-control">
                                        </div>
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-primary pull-right">Update</button>
                                <div class="clearfix"></div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>


            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title ">All Contacts</h4>
                            <p class="card-category">you can see all contacts here</p>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover" id="dataTable">
                                    <thead class="text-primary">
                                        <th>
                                            ID
                                        </th>
                                        <th>
                                            Name
                                        </th>
                                        <th>
                                            Email
                                        </th>
                                        <th>
                                            phone
                                        </th>
                                        <th>
                                            message
                                        </th>
                                        <th>
                                            Edit
                                        </th>
                                        <th>
                                            Delete
                                        </th>
                                    </thead>
                                    <tbody>
                                        <?php
                                        foreach ($records as $record) {
                                        ?>
                                            <tr>
                                                <td>
                                                    <?php echo $record["id"] ?>
                                                </td>
                                                <td>
                                                    <?php echo $record["name"] ?>
                                                </td>
                                                <td>
                                                    <?php echo $record["email"] ?>
                                                </td>
                                                <td>
                                                    <?php echo $record["phone"] ?>
                                                </td>
                                                <td>
                                                    <?php echo $record["message"] ?>
                                                </td>
                                                <td class="text-primary">
                                                    <label class="text-primary" for="<?php echo $record["id"] ?>">Edit</a>
                                                        <input type="button" onclick="fill_input_labels( '<?php echo $record['name'] ?>' , '<?php echo $record['email'] ?>' , '<?php echo $record['phone'] ?>' , '<?php echo $record['message'] ?>' , '<?php echo $record['id'] ?>' );" id="<?php echo $record["id"] ?>" value="<?php echo $record["id"] ?>" style="display: none;" />
                                                </td>
                                                <td>
                                                    <button type=" button" onclick="del_sub(this.value);" value="<?php echo $record["id"] ?>" id="del_btns" rel="tooltip" title="Remove" class="btn btn-danger btn-link btn-sm">
                                                        <a class="text-danger" href="#">Remove</a>
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


</Body>

<script>
    // Show msg
    var msg = sessionStorage.getItem("c_msg");

    if (msg == "1") {
        swal('Success');
        sessionStorage.setItem("c_msg", "");
    } else if (msg == "0") {
        swal('Failed');
        sessionStorage.setItem("c_msg", "");

    }

    // clear the form fileds
    document.getElementById("Cname").value = "";
    document.getElementById("Cemail").value = "";
    document.getElementById("Cphone").value = "";
    document.getElementById("Cmessage").value = "";
    document.getElementById("Cid").value = "";


    // Fill out the form
    function fill_input_labels(name, email, phone, message, id) {

        document.getElementById("Cname").value = name;
        document.getElementById("Cemail").value = email;
        document.getElementById("Cphone").value = phone;
        document.getElementById("Cmessage").value = message;
        document.getElementById("Cid").value = id;

    }


    // Delete data
    function del_sub(value) {
        document.cookie = "deleted_value=" + value;
        swal({
                title: "Are you sure?",
                text: "You will not be able to recover this record!",
                type: "warning",
                showCancelButton: true,
                confirmButtonClass: "btn-danger",
                confirmButtonText: "Yes, delete it!",
                cancelButtonText: "No, cancel plx!",
                closeOnConfirm: false,
                closeOnCancel: false
            },
            function(isConfirm) {
                if (isConfirm) {

                    <?php
                    $key_value = $_COOKIE["deleted_value"];
                    if ($key_value != 0) {
                        $DB->del_contact($key_value);
                        echo "history.go(0);";
                    }
                    ?>

                    swal("Deleted!", "Your record has been deleted.", "success");

                } else {
                    swal("Cancelled", "Your record is safe :)", "error");
                }
            });
    }
</script>








<!-- Footer -->
<?php include('../includes/footer.php'); ?>