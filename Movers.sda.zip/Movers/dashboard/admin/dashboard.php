<!-- Header -->
<?php include('../includes/header.php'); ?>


<?php

session_start();
$uname = $_SESSION['sign_in_uname'];
$pass = $_SESSION['sign_in_pass'];

if (strlen($_SESSION['sign_in_uname']) >= 1) {
    $DB = new SDA_Movers();
    $records = $DB->select_order(NULL);
} else {
    header('location:index.php');
}

?>


<!-- Body -->

<Body class="body">
    <!-- Nav -->
    <?php include('../includes/navbar.php'); ?>


    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-header card-header-warning card-header-icon">
                            <div class="card-icon">
                                <i class="material-icons">collections_bookmark</i>
                            </div>
                            <p class="card-category">Total Orders</p>
                            <h3 class="card-title"><?php

                                                    $count = 0;

                                                    foreach ($records as $record) {
                                                        $count += 1;
                                                    }

                                                    echo $count;

                                                    ?>
                                <!-- <small>$</small> -->
                            </h3>
                        </div>
                        <div class="card-footer">
                            <div class="stats">
                                <i class="material-icons">attach_money</i>
                                <a href="javascript:;">based on current month <script>
                                        document.write(new Date().getMonth())
                                    </script></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-header card-header-success card-header-icon">
                            <div class="card-icon">
                                <i class="material-icons">money</i>
                            </div>
                            <p class="card-category">Total Revenue</p>
                            <h3 class="card-title">Dirham. <?php
                                                            echo $count*2300;
                                                            ?>
                            </h3>
                        </div>
                        <div class="card-footer">
                            <div class="stats">
                                <i class="material-icons">date_range</i>
                                <a href="javascript:;">based on current year <script>
                                        document.write(new Date().getFullYear())
                                    </script></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-header card-header-danger card-header-icon">
                            <div class="card-icon">
                                <i class="material-icons">reorder</i>
                            </div>
                            <p class="card-category">New Orders</p>
                            <h3 class="card-title">
                                <?php

                                $count_new_order = 0;

                                foreach ($records as $record) {
                                    if ($record["read_status"] == 1) {
                                        $count_new_order += 1;
                                    }
                                }

                                echo $count_new_order;

                                ?>
                            </h3>
                        </div>
                        <div class="card-footer">
                            <div class="stats">
                                <i class="material-icons">local_offer</i> Tracked from Database
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="card card-stats">
                        <div class="card-header card-header-info card-header-icon">
                            <div class="card-icon">
                                <i class="material-icons">message</i>
                            </div>
                            <p class="card-category">Pending Tasks</p>
                            <h3 class="card-title">
                                <?php

                                $count_p = 0;

                                foreach ($records as $record) {
                                    if ($record["status"] == "In Processing") {
                                        $count_p += 1;
                                    }
                                }

                                echo $count_p;

                                ?>
                            </h3>
                        </div>
                        <div class="card-footer">
                            <div class="stats">
                                <i class="material-icons">update</i> Just Updated
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="card card-chart">
                        <div class="card-header card-header-success">
                            <div class="ct-chart" id="dailySalesChart"></div>
                        </div>
                        <div class="card-body">
                            <h4 class="card-title">Package Analyis</h4>
                            <p class="card-category">
                                <span class="text-success"><i class="fa fa-long-arrow-up"></i> 55% </span> increase in today orders.</p>
                        </div>
                        <div class="card-footer">
                            <div class="stats">
                                <i class="material-icons">access_time</i> updated by today
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="card card-chart">
                        <div class="card-header card-header-warning">
                            <div class="ct-chart" id="websiteViewsChart"></div>
                        </div>
                        <div class="card-body">
                            <h4 class="card-title">Area type</h4>
                            <p class="card-category">Last Campaign Performance</p>
                        </div>
                        <div class="card-footer">
                            <div class="stats">
                                <i class="material-icons">access_time</i> updated by today
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card card-chart">
                        <div class="card-header card-header-danger">
                            <div class="ct-chart" id="completedTasksChart"></div>
                        </div>
                        <div class="card-body">
                            <h4 class="card-title">Package Type</h4>
                            <p class="card-category">Last Campaign Performance</p>
                        </div>
                        <div class="card-footer">
                            <div class="stats">
                                <i class="material-icons">access_time</i> updated by today
                            </div>
                        </div>
                    </div>
                </div>
            </div>



        </div>
    </div>


</Body>


<script>
    // we simulate the window Resize so the charts will get updated in realtime.
    var simulateWindowResize = setInterval(function() {
        window.dispatchEvent(new Event('resize'));
    }, 280);

    // we stop the simulation of Window Resize after the animations are completed
    setTimeout(function() {
        clearInterval(simulateWindowResize);
    }, 1000);
</script>
<script>
    $(document).ready(function() {
        // Javascript method's body can be found in assets/js/materialcharts.js

        md.initDashboardPageCharts();

    });
</script>



<!-- Footer -->
<?php include_once('../includes/footer.php'); ?>