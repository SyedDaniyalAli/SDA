<!-- Header -->
<?php include('../includes/header.php'); ?>

<?php

session_start();
$uname = $_SESSION['sign_in_uname'];
$pass = $_SESSION['sign_in_pass'];

if (strlen($_SESSION['sign_in_uname']) >= 1) {
    $DB = new SDA_Movers();
    $records = $DB->select_order(NULL);
} else {
    header('location:index.php');
}

?>

<!-- Body -->

<Body class="body">
    <!-- Nav -->
    <?php include('../includes/navbar.php'); ?>

    <div class="content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title">Update Orders</h4>
                            <p class="card-category">update your contacts</p>
                        </div>
                        <div class="card-body">
                            <form action="../webApis/update_order.php" method="POST">
                                <div class="row">

                                    <input id="Oid" name="Oid" type="hidden" class="form-control">

                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="bmd-label-floating">Order ID</label>
                                            <input required id="Oorder_id" name="Oorder_id" type="text" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="bmd-label-floating">Name</label>
                                            <input required id="Oname" name="Oname" type="text" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="bmd-label-floating">Email</label>
                                            <input required id="Oemail" name="Oemail" type="email" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="bmd-label-floating">Phone</label>
                                            <input required id="Ophone" name="Ophone" type="text" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="bmd-label-floating">Services</label>
                                            <input required id="Oservices" name="Oservices" type="text" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="bmd-label-floating">Area Type</label>
                                            <input required id="Oarea_type" name="Oarea_type" type="text" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="bmd-label-floating">Package type</label>
                                            <input required id="Opkg_type" name="Opkg_type" type="text" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="bmd-label-floating">Pickup</label>
                                            <input required id="Opick_up" name="Opick_up" type="text" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="bmd-label-floating">Dropout</label>
                                            <input required id="Odrop_out" name="Odrop_out" type="text" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="bmd-label-floating">Date</label>
                                            <input required id="Odate" name="Odate" type="date" class="form-control">
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <label class="bmd-label-floating">Description</label>
                                            <input required id="Odec" name="Odec" type="text" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="bmd-label-floating">Status</label>
                                            <select required id="Ostatus" name="Ostatus" type="select" class="form-control">
                                                <option>Completed</option>
                                                <option>In Processing</option>
                                                <option>Canceled</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="bmd-label-floating">Read Status</label>
                                            <select required id="Oread_status" name="Oread_status" type="select" class="form-control">
                                                <option>1</option>
                                                <option>0</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <button type="submit" class="btn btn-primary pull-right">Update</button>
                                <div class="clearfix"></div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>


            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title ">All Orders</h4>
                            <p class="card-category">you can see all orders here</p>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover table-bordered" id="dataTable">
                                    <thead class="text-primary">
                                        <th>
                                            ID
                                        </th>
                                        <th>
                                            ID Order
                                        </th>
                                        <th>
                                            Name
                                        </th>
                                        <th>
                                            Email
                                        </th>
                                        <th>
                                            phone
                                        </th>
                                        <th>
                                            service
                                        </th>
                                        <th>
                                            areatype
                                        </th>
                                        <th>
                                            packagetype
                                        </th>
                                        <th>
                                            pickup
                                        </th>
                                        <th>
                                            dropout
                                        </th>
                                        <th>
                                            date
                                        </th>
                                        <th>
                                            description
                                        </th>
                                        <th>
                                            status
                                        </th>
                                        <th>
                                            read_status
                                        </th>
                                        <th>
                                            Edit
                                        </th>
                                        <th>
                                            Delete
                                        </th>
                                    </thead>
                                    <tbody>
                                        <?php
                                        foreach ($records as $record) {
                                        ?>
                                            <tr>
                                                <td>
                                                    <?php echo $record["id"] ?>
                                                </td>
                                                <td>
                                                    <?php echo $record["orderid"] ?>
                                                </td>
                                                <td>
                                                    <?php echo $record["name"] ?>
                                                </td>
                                                <td>
                                                    <?php echo $record["phone"] ?>
                                                </td>
                                                <td>
                                                    <?php echo $record["email"] ?>
                                                </td>
                                                <td>
                                                    <?php echo $record["service"] ?>
                                                </td>
                                                <td>
                                                    <?php echo $record["areatype"] ?>
                                                </td>
                                                <td>
                                                    <?php echo $record["packagetype"] ?>
                                                </td>
                                                <td>
                                                    <?php echo $record["pickup"] ?>
                                                </td>
                                                <td>
                                                    <?php echo $record["dropout"] ?>
                                                </td>
                                                <td>
                                                    <?php echo $record["date"] ?>
                                                </td>
                                                <td>
                                                    <?php echo $record["description"] ?>
                                                </td>
                                                <td>
                                                    <?php echo $record["status"] ?>
                                                </td>
                                                <td>
                                                    <?php echo $record["read_status"] ?>
                                                </td>
                                                <td class="text-primary">
                                                    <label class="text-primary" for="<?php echo $record["id"] ?>">Edit</a>
                                                        <input type="button" onclick="fill_input_labels( '<?php echo $record['orderid'] ?>' ,
                                                         '<?php echo $record['name'] ?>' , '<?php echo $record['phone'] ?>' , 
                                                         '<?php echo $record['email'] ?>' ,'<?php echo $record['service'] ?>' ,
                                                         '<?php echo $record['areatype'] ?>','<?php echo $record['packagetype'] ?>',
                                                         '<?php echo $record['pickup'] ?>','<?php echo $record['dropout'] ?>',
                                                         '<?php echo $record['date'] ?>','<?php echo $record['description'] ?>' ,
                                                         '<?php echo $record['status'] ?>','<?php echo $record['read_status'] ?>' ,
                                                         '<?php echo $record['id'] ?>' );" id="<?php echo $record["id"] ?>" value="<?php echo $record["id"] ?>" style="display: none;" />
                                                </td>
                                                <td>
                                                    <button type=" button" onclick="del_sub(this.value);" value="<?php echo $record["id"] ?>" id="del_btns" rel="tooltip" title="Remove" class="btn btn-danger btn-link btn-sm">
                                                        <a class="text-danger" href="#">Remove</a>
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


</Body>

<script>
    // Show msg
    var msg = sessionStorage.getItem("c_msg");

    if (msg == "1") {
        swal('Success');
        sessionStorage.setItem("c_msg", "");
    } else if (msg == "0") {
        swal('Failed');
        sessionStorage.setItem("c_msg", "");

    }

    // clear the form fileds
    document.getElementById("Oid").value = "";
    document.getElementById("Oorder_id").value = "";
    document.getElementById("Oname").value = "";
    document.getElementById("Oemail").value = "";
    document.getElementById("Ophone").value = "";
    document.getElementById("Oservices").value = "";
    document.getElementById("Oarea_type").value = "";
    document.getElementById("Opkg_type").value = "";
    document.getElementById("Opick_up").value = "";
    document.getElementById("Odrop_out").value = "";
    document.getElementById("Odate").value = "";
    document.getElementById("Odec").value = "";
    document.getElementById("Ostatus").value = "";
    document.getElementById("Oread_status").value = "";



    // Fill out the form
    function fill_input_labels(Oorder_id, Oname, Oemail, Ophone, Oservices, Oarea_type, Opkg_type, Opick_up, Odrop_out, Odate, Odec, Ostatus, Oread_status, id) {

        document.getElementById("Oid").value = id;
        document.getElementById("Oorder_id").value = Oorder_id;
        document.getElementById("Oname").value = Oname;
        document.getElementById("Oemail").value = Oemail;
        document.getElementById("Ophone").value = Ophone;
        document.getElementById("Oservices").value = Oservices;
        document.getElementById("Oarea_type").value = Oarea_type
        document.getElementById("Opkg_type").value = Opkg_type;
        document.getElementById("Opick_up").value = Opick_up;
        document.getElementById("Odrop_out").value = Odrop_out;
        document.getElementById("Odate").value = Odate,
            document.getElementById("Odec").value = Odec;
        document.getElementById("Ostatus").value = Ostatus;
        document.getElementById("Oread_status").value = Oread_status;


    }

    // Delete data
    function del_sub(value) {
        document.cookie = "deleted_value=" + value;
        swal({
                title: "Are you sure?",
                text: "You will not be able to recover this record!",
                type: "warning",
                showCancelButton: true,
                confirmButtonClass: "btn-danger",
                confirmButtonText: "Yes, delete it!",
                cancelButtonText: "No, cancel plx!",
                closeOnConfirm: false,
                closeOnCancel: false
            },
            function(isConfirm) {
                if (isConfirm) {

                    <?php
                    $key_value = $_COOKIE["deleted_value"];
                    if ($key_value != 0) {
                        $DB->del_order($key_value);
                        echo "history.go(0);";
                    }
                    ?>

                    swal("Deleted!", "Your record has been deleted.", "success");

                } else {
                    swal("Cancelled", "Your record is safe :)", "error");
                }
            });
    }
</script>








<!-- Footer -->
<?php include('../includes/footer.php'); ?>