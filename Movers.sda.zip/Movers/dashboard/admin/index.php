<!-- Header -->
<?php include('../includes/header.php'); ?>

<?php
session_start();
error_reporting(0);

?>

<!-- Body -->

<script>
    $(document).ready(function() {
        $("#loginBtn").click(function(event) {
            event.preventDefault();
            var email_txt = $("#email_txt").val();
            var pass_txt = $("#pass_txt").val();
            $.ajax({
                url: "../webApis/login.php",
                type: "POST",
                dataType: "text",
                async: true,
                data: {
                    'username': email_txt,
                    'password': pass_txt
                },
                success: function(response, status, xhr) {

                    if (response == 1) {
                        window.location.href = "dashboard.php";
                    } else {
                        md.showNotification('bottom', 'center', 'Inavlid Crendentials', 'error');
                    }

                },
                error: function(xhr, textStatus, errorThrown) {
                    // alert('request failed');
                    swal(errorThrown);
                }
            });
        });
    });
</script>

<Body class="body">

    <div class="content">
        <div class="container">

            <div class="container-fluid text-center">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header ">
                                <h2 class="card-title">Fox Movers</h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title">Login Profile</h4>
                            <p class="card-category">Please login to access panel</p>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="#" enctype="multipart/form-data">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="bmd-label-floating">Username or Email</label>
                                            <input type="text" id="email_txt" name="user_email" class="form-control">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label class="bmd-label-floating">Password</label>
                                            <input type="text" id="pass_txt" name="passwd" class="form-control">
                                        </div>
                                    </div>
                                </div>

                                <button type="submit" id="loginBtn" class="btn btn-primary pull-right">Login</button>
                                <div class="clearfix"></div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

</Body>

<?php require('../assets/materialcharts/materialcharts.php'); ?>







<!-- Footer -->
<?php include('../includes/footer.php'); ?>