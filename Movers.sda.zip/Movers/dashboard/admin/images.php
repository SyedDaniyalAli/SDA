<!-- Header -->
<?php include('../includes/header.php'); ?>

<?php

session_start();
$uname = $_SESSION['sign_in_uname'];
$pass = $_SESSION['sign_in_pass'];

if (strlen($_SESSION['sign_in_uname']) >= 1) {
} else {
    header('location:index.php');
}

?>

<!-- Body -->

<Body class="body">
    <!-- Nav -->
    <?php include('../includes/navbar.php'); ?>

    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title">Slider Image 1</h4>
                            <p class="card-category">update your images of slider in 1920x760</p>
                        </div>
                        <div class="card-body">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <form action="../webApis/image_uploading.php" method="post" enctype="multipart/form-data">
                                        <div class="col-md-2">
                                            <div class="row">
                                                <label for="fileButton" id="image1Lb" class="bmd-label-floating text-danger">click to upload image one</label>
                                                <input type='file' name="fileToUpload" onchange="readURL1(this);" id="fileButton" />
                                            </div>
                                        </div>
                                        <div class="row">
                                            <!-- http://placehold.it/180 -->
                                            <img id="ImgTag1" src="" />
                                        </div>
                                        <div class="row">
                                            <button type="submit" name="submit" class="btn btn-outline-primary pull-right">Upload Image</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title">Slider Image 2</h4>
                            <p class="card-category">update your images of slider in 1920x760</p>
                        </div>
                        <div class="card-body">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <form action="../webApis/image_uploading.php" method="post" enctype="multipart/form-data">
                                        <div class="col-md-2">
                                            <div class="row">
                                                <label for="fileButton2" id="image2Lb" class="bmd-label-floating text-danger">click to upload image one</label>
                                                <input type='file' name="fileToUpload" onchange="readURL2(this);" id="fileButton2" />
                                            </div>
                                        </div>
                                        <div class="row">
                                            <!-- http://placehold.it/180 -->
                                            <img id="ImgTag2" src="" />
                                        </div>
                                        <div class="row">
                                            <button type="submit" name="submit" class="btn btn-outline-primary pull-right">Upload Image</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-header-primary">
                            <h4 class="card-title">Slider Image 3</h4>
                            <p class="card-category">update your images of slider in 1920x760</p>
                        </div>
                        <div class="card-body">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <form action="../webApis/image_uploading.php" method="post" enctype="multipart/form-data">
                                        <div class="col-md-2">
                                            <div class="row">
                                                <label for="fileButton3" id="image3Lb" class="bmd-label-floating text-danger">click to upload image one</label>
                                                <input type='file' name="fileToUpload" onchange="readURL3(this);" id="fileButton3" />
                                            </div>
                                        </div>
                                        <div class="row">
                                            <!-- http://placehold.it/180 -->
                                            <img id="ImgTag3" src="" />
                                        </div>
                                        <div class="row">
                                            <button type="submit" name="submit" class="btn btn-outline-primary pull-right">Upload Image</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>

</Body>

<script>
    // Show msg
    var msg = sessionStorage.getItem("c_msg");

    if (msg == "1") {
        swal('Success');
        sessionStorage.setItem("c_msg", "");
    } else if (msg.length > 1) {
        swal(msg);
        sessionStorage.setItem("c_msg", "");

    }
</script>

<!-- imgTag1,2,3 are in personal.js -->

<!-- Footer -->
<?php include('../includes/footer.php'); ?>